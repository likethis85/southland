var baidu = baidu || {};
baidu.editor = baidu.editor || {};
baidu.editor.ui = {};